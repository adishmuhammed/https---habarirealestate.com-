
<div class="header">

    <nav class="navbar navbar-default   navbar-mobile bootsnav">

        <div class="container">
 <div class="attr-nav">
                        <ul>
                          
                        
                                                    <li >
                                                        <div class="head-login">
                                                        <a href="">Submit Property</a></div></li>
                                                      
                        </ul>
                    </div>

            <!-- Start Header Navigation -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" href="<?php echo site_url("LoginController/index");?>"><img src="<?=base_url()?>assets/img/logo.png" class="logo" alt=""></a>
            </div>
            <!-- End Header Navigation -->

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse menu2" id="navbar-menu">
                <ul class="nav navbar-nav " data-in="fadeInDown" data-out="fadeOutUp">
                 
               
                 
                     <li class=""><a href="<?php echo site_url("LoginController/menu");?>">Properties</a></li>
                    <li class=""><a href="">About us</a></li>
                    <li class=""><a href="#">Contact us</a></li>
                     <li><a class="ar" onclick="updateLang('arb')">العربية</a></li>


                </ul>
                
               
            </div><!-- /.navbar-collapse -->
        </div>
    </nav>
</div>