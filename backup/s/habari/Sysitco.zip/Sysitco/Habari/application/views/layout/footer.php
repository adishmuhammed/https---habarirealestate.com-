<div class="footer" >

    <div class="container margin-auto">
        <div class="row">
    
    </div>
    <div class="copy-right">
        <div class="container">
        <p>© 2022 Copyright Al Habari Realestate All right reserved.</p>
            </div>
    </div>
</div>
<script src="<?=base_url()?>assets/js/bootstrap.js"></script>
    <script src="<?=base_url()?>assets/js/jquery.gwmenu.js"></script>
  
    <script src="<?=base_url()?>assets/js/main.js"></script>
    <script src="<?=base_url()?>assets/js/script.js"></script>
    <script> var owl = $('.pro-img');
        owl.owlCarousel({
            margin: 0,
            loop: true,
            thumbs: true,
        thumbImage: true,
        thumbContainerClass: 'owl-thumbs',
        thumbItemClass: 'owl-thumb-item',
            autoplay: true,
            autoplayTimeout: 3000,
            autoplayHoverPause: true,
            dots: false,
            responsive: {
                0: {
                    items: 1,
                    margin: 10,
                    dots: true,
                },
                600: {
                    items: 1,
                    dots: true
                },
                1000: {
                    items: 1,
                }
            }
        })</script>
        
 
</body>

</html>
