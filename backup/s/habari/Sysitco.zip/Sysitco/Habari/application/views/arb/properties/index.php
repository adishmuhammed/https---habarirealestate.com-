

   
   

        <div class="main-slider clearfix">
       
            <div class="swiper-container gallery-top" data-aos="fade-up" data-aos-duration="500">
                <div class="swiper-wrapper">
                  
                    <div class="swiper-slide">
                      
                        
                   <img src="<?=base_url()?>slider/1.jpg" class="full-width" alt="K Mart">
                       
                    </div>
                     <div class="swiper-slide">
                       
                        
                   <img src="<?=base_url()?>slider/1.jpg" class="full-width" alt="K Mart">
                 
                    </div>
                        
                </div>


            </div>
            <div class="swiper-controller">
 <div class="swiper-pagination"></div>
            </div>
        </div>
  


   
 <div class="home-category" data-aos="fade-up" data-aos-duration="500">
    <div class="container">
         <div class="row">
        <h1>Featured Properties</h1>

      
            <ul class="home-featured owlcarousel">
                <?php if(!empty($propertyList))
                      {

                       $i = 1;
                       foreach($propertyList as $value) 
                  {
                     
                     ?>
                      <?php
                        if(empty( $value->pro_image))
                            {
                                ?>
                                <a href="<?php echo site_url("LoginController/index/".$value->pro_id);?>"> <img src="<?=base_url()?>uploads/images/no_image.png" width="250px" height="255px"alt="">
                                    <?php
                                }
                                else
                                {


                                ?>
                                <li><<a href="<?php echo site_url("LoginController/index/".$value->pro_id);?>"><img src="<?=base_url()?>uploads/images/<?= $value->pro_image; ?>" width="250px" height="255px"alt="">
                        <?php
                    }
                    ?>
            
                    <h3 class="hprice">QR <?= $value->pro_price;?></h3>
                    <span class="flabel">Featured</span>
                    <div  class="hftext">
                    <h4><a href=" ">Villa, Al Waab / Al Aziziya / New Al Ghanim</a></h4>
                    <h2><?= $value->pro_title;?></h2>
                    
                    <p class="date">1 Day Ago</p>
                        </div>
                    </a>
                
                </li>
                 <?php 

                  $i++;  
                }
                 
                   }

                   ?>
                 
                 
                
                 
            </ul>
                 
        
        </div></div>
    </div>

    
    
    
    <div class="home-mid-section">
   <div class="mid-content">
        <div class="mid-right">
       <img src="assets/img/mid-img.png" alt=""> 
       </div>
       <div class="container">
       <h3>Sell your best <br>
       Cozy Place
       </h3></div>
       <div class="mid-foot">
           
       <div class="container">
           <h2>We provide a complete service for the sale, <br>purchase or rental of real estate.</h2>
             <a class="btns" href="">Contact Us</a>
           </div> 
        </div>
    
    </div>  </div>
    
       <div  class="home-welcome-section"  data-aos="fade-down" data-aos-duration="500">
             
           
              
                        <div class="container">  
<div class="row">
                <div class="col-md-4" data-aos="fade-right" data-aos-duration="500">
                           <img src="<?=base_url()?>assets/img/home-about.png" class="full-width" alt="">
                            
                            </div>
     <div class="col-md-8"  data-aos="fade-left" data-aos-duration="1000">
   <div class="bl">
         <h3>About Us</h3>
                  
         <div class="clearfix"></div>
         <h2>Helping People to Find their Home</h2>
             <p>
Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
</p>
              
         <a href="" class="btn readmore">Know more</a>
                   </div>     </div>
              
          
        </div>
       
    
        </div>
    </div>
    <div class="clearfix"></div>
 
 <div class="home-bottom">
    <div class="container">
     <div class="home-sub">
         <div class="container">
        
         <h2>Looking to Buy/Rent a new property <br>or Sell an existing one?</h2>
            
            <p> Al Habari provides an awesome solution! </p>
         <div class="btn-wrap">
    <a class="btns" href="">Submit Property</a>
               <a class="btns" href="">Browse Properties</a>
             </div>
         
        
         </div>
        
        </div>
     </div>
    </div>
  
     <div  class="home-reviews">
    <div class="container">
        <p>Client Reviews</p>
        <h2>What our Customer Saying</h2>
        <ul class="owlcarousel reviews">
        
        <li>
            <i class="fa fa-quote-right"></i>
            
            <p>"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s"</p>
            <h3>Mearsk</h3>
            
            </li>
             <li>
            <i class="fa fa-quote-right"></i>
            <p>"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s"</p>
            <h3>Mearsk</h3>
            
            </li>
             <li>
            <i class="fa fa-quote-right"></i>
            <p>"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s"</p>
            <h3>Mearsk</h3>
            
            </li>
        </ul>
        
        </div>
    </div>
    
<!--<?php include 'footer.php';?>-->
  
    </div>
    <script src="<?=base_url()?>assets/js/bootstrap.js"></script>
    <script src="<?=base_url()?>assets/js/jquery.gwmenu.js"></script>
    
    <script src="<?=base_url()?>assets/js/homeslider.js"></script>
    <script>
        AOS.init();
        var galleryTop = new Swiper('.gallery-top', {
            nextButton: '.swiper-button-next',
            prevButton: '.swiper-button-prev',
            spaceBetween: 0,
            loop: true,
            effect: 'fade',
            autoplay: true,
            speed: 1600,
            loopedSlides: 5, //looped slides should be the same     
            pagination: '.swiper-pagination',
            paginationClickable: true,
            /* direction: 'vertical',*/
            /* parallax: false,*/
            autoplay: 1600
        });


         var owl = $('.home-featured');
        owl.owlCarousel({
            margin: 15,
            loop: true,
            autoplay: false,
            autoplayTimeout: 3000,
            autoplayHoverPause: true,
            dots: false,
            responsive: {
                0: {
                    items: 2,
                    margin: 10,
                    dots: true,
                },
                600: {
                    items: 2,
                    dots: true
                },
                1000: {
                    items: 4,
                }
            }
        })
        
        
         var owl = $('.reviews');
        owl.owlCarousel({
            margin: 30,
            loop: true,
            autoplay: false,
            autoplayTimeout: 3000,
            autoplayHoverPause: true,
            dots: false,
            responsive: {
                0: {
                    items: 1,
                    margin: 10,
                    dots: true,
                },
                600: {
                    items: 1,
                    dots: true
                },
                1000: {
                    items:3,
                }
            }
        })
        
        
       
        
       
    </script>
</body>

</html>
