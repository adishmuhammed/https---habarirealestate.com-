<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <link rel="icon" href="assets/ico.png">
    <title>Habari</title>
    <!-- Bootstrap core CSS -->
    <link href="<?=base_url()?>assets/css/bootstrap.css" rel="stylesheet">
    <link href="<?=base_url()?>assets/css/reset.css" rel="stylesheet">
    <link href="<?=base_url()?>assets/aos/aos.css" rel="stylesheet">
    <link href="<?=base_url()?>assets/css/gwmenu.css" rel="stylesheet">
    <link href="<?=base_url()?>assets/css/font-awesome.css" rel="stylesheet">
    <link href="<?=base_url()?>assets/css/line-awesome.min.css" rel="stylesheet">
    <link href="<?=base_url()?>assets/css/slider.css" rel="stylesheet">
    <link href="<?=base_url()?>assets/css/style.css" rel="stylesheet">
        <link href="<?=base_url()?>assets/css/owl.carousel.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxbookn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxbookn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

    <script src="<?=base_url()?>assets/js/jquery.min.js"></script>
    <script src="<?=base_url()?>assets/aos/aos.js"></script>
    <script src="<?=base_url()?>assets/js/modernizr.js"></script>
    <script src="<?=base_url()?>assets/js/owl.carousel.min.js"></script>
  
  


  



</head>

<body>
   <div class="layout">