

   
   

 <div class="innerpage item-details">
     <div class="row">
    <div class="container">
     <div class="row">
        
        <div class="col-md-9 pad0">
             <h1><?=$propertyList->pro_title;?></h1>
            <p class="idate">Updated about 5 hours ago</p>
            
         <div class="product-img">

         
         <?php
         if(!empty($multiDetails)) {
         $images=json_decode($multiDetails->multi_name);
         //print_r($images);

         ?>   
            
        <ul class="pro-img owl-carousel">
         
        <?php
         
        if(count($images)>0)
          {
         for($i=0;$i<count($images);$i++)
         { ?>

        <li><img src="<?=base_url()?>uploads/upimage/<?=$images[$i]->image_name ?>" width="878px" height="548px" alt=""></li>
       <?php
             }
         }
         else
         {
            ?>
             <li><img src="<?=base_url()?>uploads/images/no_image.png" width="250px" height="255px"alt=""></li>
       <?php  }
        }
         else
         {
            ?>
             <li><img src="<?=base_url()?>uploads/images/no_image.png" width="250px" height="255px"alt=""></li>
       <?php  }
        ?>

                   
        </ul>
        </div>

        <div class="product-details">
       
            
        <p><?=$propertyList->pro_description;?></p>
         <!--<p><?= $propertyList->pro_content  ;?></p>-->

        </div>
        
        
            
        <div class="fbox">
        <h2>Detail & Features</h2>
                <ul><li>Bedrooms:<?=$propertyList->pro_bedroom;?> Beds</li>
                    <li>Bathrooms:<?=$propertyList->pro_bathroom;?> Bath</li>
                    <li>Square:<?=$propertyList->pro_square;?> m²</li>
                    <li>Floors:<?=$propertyList->pro_floor;?></li>
                    <li>Property Type:
                        <?php
                          foreach($typeList  as $value) 
                          {
                               if( $propertyList->re_typeid==$value->re_typeid)
                               {
                                echo $value->re_typename;
                               }  
                           }           
                          ?>

                    </li>
                </ul>
            
        </div>
      
        
            
        <div class="fec">
        <h2>Amenities</h2>
            <ul>
            <?php
              foreach($fList as $value) 
              {
                
                  $feature= explode(',', $propertyList->re_featureid);
                if( in_array($value->re_featureid, $feature)){

            ?>

                <li><i class="fa fa-car"></i><?= $value->re_featuretitle; ?></li>
            <?php
                  } 

                  }          
            ?>
                 
             </ul>
        </div>
        </div>
         <div class="col-md-3">
            <div class="hsidebar">
              
                
                <h2 class="pricebar">QAR<?=$propertyList->pro_price;?></h2>
                <div class="hcontact">
                <a class="call" href=""><i class="fa fa-phone"></i></a>
                  <a class="whatsapp" href=""><i class="fa fa-whatsapp"></i></a>
                      <a class="whatsapp" href=""><i class="fa fa-share"></i></a>
                </div>
                
                <h3>Location</h3>
                <div class="hmap">
                
                </div>
               
             </div>
        </div>
         
       <div class="clearfix"></div>
         
         <div class="pro-list">
             <h2>See other similar properties</h2>
             <div class="clearfix"></div>
              <ul class="row">
                <?php if(!empty($propertyList1))
                      {

                           $i = 1;
                           foreach($propertyList1 as $value) 
                           {
                         
                ?>
                    <li class="col-md-3">
                    <div class="item">
                        <?php
                        if(empty( $value->pro_image))
                        {
                            ?>
                            <a href="<?php echo site_url("LoginController/details/".$value->pro_id);?>"> <img src="<?=base_url()?>uploads/images/no_image.png" width="250px"height="255px"alt="">
                            <?php
                        }
                        else
                        {


                        ?>
                            <a href="<?php echo site_url("LoginController/details/".$value->pro_id);?>"><img src="<?=base_url()?>uploads/images/<?= $value->pro_image; ?>" width="250px" height="255px"alt="">
                        <?php
                        }
                        ?>
                        <h3 class="hprice">QR 20000</h3>
                        <span class="flabel">Featured</span>
                        <div  class="hftext">
                        <h4><a href="">Villa, Al Waab / Al Aziziya / New Al Ghanim</a></h4>
                        <h2>Two Bedroom Upper Floor Villa</h2>
                        
                        <p class="date">1 Day Ago</p>
                        </div>
                        </a>
                    </div>
                    <?php 

                    $i++;  
                    }
                 
                    }

                   ?>
               

                  
                 
            </ul>
             </div>  
        </div>
        
     
     
    </div></div>
    </div>

   
  
 
 

