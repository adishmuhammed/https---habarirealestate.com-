

    <!-- <?php  $p=''; include 'menu2.php';?>-->
   


 <div class="innerpage product-details-page">
     <div class="row">
    <div class="container">
     <div class="row">
   <div class="filter-bar"></div>
                  <div class="pro-list">
              <ul class="row">
                <?php if(!empty($propertyList))
                      {

                       $i = 1;
                       foreach($propertyList as $value) 
                  {
                     
                     ?>
                <li class="col-md-3">
                    
                    <div class="item">
                        <?php
                        if(empty( $value->pro_image))
                            {
                                ?>
                                <a href="<?php echo site_url("LoginController/details/".$value->pro_id);?>"> <img src="<?=base_url()?>uploads/images/no_image.png" width="250px" height="255px"alt="">
                                    <?php
                                }else
                                {


                                ?>
                    <a href="<?php echo site_url("LoginController/details/".$value->pro_id);?>"><img src="<?=base_url()?>uploads/images/<?= $value->pro_image; ?>" width="250px" height="255px"alt="">
                        <?php
                    }
                    ?>
                    <h3 class="hprice">QR <?= $value->pro_price;?></h3>
                    <span class="flabel">Featured</span>
                    <div  class="hftext">
                    <h4><a href="">Villa, Al Waab / Al Aziziya / New Al Ghanim</a></h4>
                    <h2><?= $value->pro_title;?></h2>
                    
                    <p class="date">1 Day Ago</p>
                        </div>
                    </a>
                </div>

                <?php 

                  $i++;  
                }
                 
                   }

                   ?>
               
                
                  
                 
            </ul>
             </div>  
       
        </div>
        
       

    </div></div>
  
  
       </div>
  
 
 


   
