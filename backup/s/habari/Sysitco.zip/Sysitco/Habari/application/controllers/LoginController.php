<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class LoginController extends CI_Controller 
{
	function __construct()
	{
		parent::__construct();

		$this->load->helper('form');
		// $this->load->library('form_validation');
		$this->load->model('LoginModel');
		if($this->session->userdata('language')==FALSE)
		{
			$lang='en';
			$this->session->userdata('language',$lang);

		}
	}

	 public function index()
	{
		{
		
		$limit=10;
		$con="(pro_delete=0)";
		$data["propertyList"]=$pList=$this->LoginModel->limit('re_property',$con,$limit);

		$lang=$this->session->userdata('language');
			if($lang='en')
			{

				$this->load->view('layout/header');
				$this->load->view('layout/menu2');
				$this->load->view('properties/index',$data);
				$this->load->view('layout/footer');
			}
			else
			{
				$this->load->view('arb/layout/header');
				$this->load->view('arb/layout/menu2');
				$this->load->view('arb/properties/index',$data);
				$this->load->view('arb/layout/footer');	
			}
		}
	}

	public function menu()
	{
		
		$con="(pro_delete=0)";
		$data["propertyList"]=$pList=$this->LoginModel->select3('re_property',$con);
		$lang=$this->session->userdata('language');
		if($lang='en')
		{


			$this->load->view('layout/header');
			$this->load->view('layout/menu2');
			$this->load->view('properties/list',$data);
			$this->load->view('layout/footer');
		}
		else
		{
			$this->load->view('arb/layout/header');
			$this->load->view('arb/layout/menu2');
			$this->load->view('arb/properties/list',$data);
			$this->load->view('arb/layout/footer');
		}
		
	}
	
	public function details($eId="")
	{
		$con="(re_typedelete=0)";
		$data["typeList"]=$typingList=$this->LoginModel->select3('re_type',$con);
		$cond="(pro_id=".$eId.")";
		$data["propertyList"]=$pList=$this->LoginModel->select1('re_property',$cond);
		$con="(re_featuredelete=0)";
		$data["fList"]=$featureList=$this->LoginModel->select3('re_features',$con);

		$data['multiDetails']=$this->LoginModel->select1('re_multiple',$cond);

		$con="(pro_delete=0)";
		$limit=4;
		$data["propertyList1"]=$pList=$this->LoginModel->limit('re_property',$con,$limit);

		$lang=$this->session->userdata('language');
		if($lang='en')
		{


			$this->load->view('layout/header');
			$this->load->view('layout/menu2');
			$this->load->view('properties/details',$data);
			$this->load->view('layout/footer');
		}
		else
		{
			$this->load->view('arb/layout/header');
			$this->load->view('arb/layout/menu2');
			$this->load->view('arb/properties/details',$data);
			$this->load->view('arb/layout/footer');
		}
	}
	public function languageUpdate()
	{

		$lang = $this->input->post('lang');
		echo $lang; die;
   		if($lang == 'en'){
      	$lang = 'en';
   }
   else
   {
     	$lang = 'arb';  
   }

  $this->session->set_userdata('language',$lang);
 
}
}