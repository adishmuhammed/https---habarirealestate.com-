
	function updateLang(lang)
{  
    alert(lang);
    var url = '<?php echo base_url(); ?>/Logincontroller/languageUpdate';
    $.ajax({
        type: 'POST',
        url: url,
        data: { lang: lang },
        success: function (data) {
            //alert(data);
            location.reload();          
        }
    });
}
